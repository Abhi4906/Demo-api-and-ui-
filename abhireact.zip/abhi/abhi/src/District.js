import axios from 'axios';
import { useEffect, useState } from 'react';

const District = () => {
  const [districtList, setDistrictList] = useState([]);
  const [formData, setFormData] = useState({ id: null, name: '', code: '' });
  const [countries, setCountries] = useState([]);
  const [countryId, setCountryId] = useState('');
  const [stateList, setStateList] = useState([]);
  const [stateId, setStateId] = useState('');

  const fetchDistricts = () => {
    axios.get("http://localhost:5273/api/Districts")
      .then((res) => setDistrictList(res.data))
      .catch((err) => console.error("Error fetching districts:", err));
  };

  const fetchStates = () => {
    axios.get('http://localhost:5273/api/States')
      .then((res) => setStateList(res.data))
      .catch((err) => console.error('Error fetching states:', err));
  };

  const fetchCountries = () => {
    axios.get('http://localhost:5273/api/Countries')
      .then((res) => setCountries(res.data))
      .catch((err) => console.error('Error fetching countries:', err));
  };

  useEffect(() => {
    fetchDistricts();
    fetchCountries();
    fetchStates();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        name: formData.name,
        code: formData.code,
        countryId: countryId,
        stateId: stateId
      };

      if (formData.id === null) {
        await axios.post('http://localhost:5273/api/Districts', payload);
        alert('District added successfully!');
      } else {
        await axios.put(`http://localhost:5273/api/Districts/${formData.id}`, {
          ...payload,
          id: formData.id
        });
        alert('District updated successfully!');
      }

      setFormData({ id: null, name: '', code: '' });
      setCountryId('');
      setStateId('');
      fetchDistricts();
    } catch (error) {
      console.error('Error saving district:', error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this district?')) return;

    try {
      await axios.delete(`http://localhost:5273/api/Districts/${id}`);
      alert('District deleted successfully!');
      fetchDistricts();
    } catch (error) {
      console.error('Error deleting district:', error);
    }
  };

  const handleEdit = (districtItem) => {
    setFormData({ id: districtItem.id, name: districtItem.name, code: districtItem.code });
    setCountryId(districtItem.countryId || '');
    setStateId(districtItem.stateId || '');
  };

  const handleCancelEdit = () => {
    setFormData({ id: null, name: '', code: '' });
    setCountryId('');
    setStateId('');
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-primary">Manage District</h2>

      <form onSubmit={handleSubmit} className="border p-4 rounded shadow-sm bg-light">
        <div className="mb-3">
          <label className="form-label">Select Country</label>
          <select
            className="form-select"
            value={countryId}
            onChange={(e) => setCountryId(e.target.value)}
            required
          >
            <option value="" disabled>-- Select Country --</option>
            {countries.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">Select State</label>
          <select
            className="form-select"
            value={stateId}
            onChange={(e) => setStateId(e.target.value)}
            required
          >
            <option value="" disabled>-- Select State --</option>
            {stateList.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">District Name</label>
          <input
            name="name"
            type="text"
            className="form-control"
            placeholder="Enter District Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">District Code</label>
          <input
            name="code"
            type="text"
            className="form-control"
            placeholder="Enter District Code"
            value={formData.code}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className={`btn ${formData.id === null ? 'btn-success' : 'btn-warning'}`}>
          {formData.id === null ? 'Submit' : 'Update'}
        </button>
        {formData.id !== null && (
          <button type="button" className="btn btn-secondary ms-2" onClick={handleCancelEdit}>
            Cancel
          </button>
        )}
      </form>

      <h4 className="mt-5">District List</h4>

      <div className="table-responsive">
        <table className="table table-bordered table-striped mt-3">
          <thead className="table-dark">
            <tr>
              <th>Id</th>
              <th>Country Name</th>
              <th>State Name</th>
              <th>District Name</th>
              <th>Code</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {districtList.map((d) => (
              <tr key={d.id}>
                <td>{d.id}</td>
                <td>{countries.find(c => c.id === d.countryId)?.name || 'Unknown'}</td>
                <td>{stateList.find(s => s.id === d.stateId)?.name || 'Unknown'}</td>
                <td>{d.name}</td>
                <td>{d.code}</td>
                <td>
                  <button className="btn btn-sm btn-primary me-2" onClick={() => handleEdit(d)}>Edit</button>
                  <button className="btn btn-sm btn-danger" onClick={() => handleDelete(d.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {districtList.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center text-muted">No districts available.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-5 text-center">
        <p className="text-muted">
          Developed by <strong>Abhishek Yadav</strong> | Final Year B.Tech Student | AKGEC Ghaziabad
        </p>
      </div>
    </div>
  );
};

export default District;
