import axios from 'axios';
import { useEffect, useState } from 'react';

const Country = () => {
  const [countries, setCountries] = useState([]);
  const [formData, setFormData] = useState({ id: null, name: '', code: '' });

  const fetchCountries = () => {
    axios.get("http://localhost:5273/api/Countries")
      .then((res) => setCountries(res.data))
      .catch((err) => console.error("Error fetching countries:", err));
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (formData.id === null) {
        await axios.post('http://localhost:5273/api/Countries', {
          name: formData.name,
          code: formData.code
        });
        alert('Country added successfully!');
      } else {
        await axios.put(`http://localhost:5273/api/Countries/${formData.id}`, formData);
        alert('Country updated successfully!');
      }

      setFormData({ id: null, name: '', code: '' });
      fetchCountries();
    } catch (error) {
      console.error('Error saving country:', error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this country?')) return;

    try {
      await axios.delete(`http://localhost:5273/api/Countries/${id}`);
      alert('Country deleted successfully!');
      fetchCountries();
    } catch (error) {
      console.error('Error deleting country:', error);
    }
  };

  const handleEdit = (country) => {
    setFormData({ id: country.id, name: country.name, code: country.code });
  };

  const handleCancelEdit = () => {
    setFormData({ id: null, name: '', code: '' });
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-primary">Manage Country</h2>

      <form onSubmit={handleSubmit} className="border p-4 rounded shadow-sm bg-light">
        <div className="mb-3">
          <label className="form-label">Country Name</label>
          <input
            name="name"
            type="text"
            className="form-control"
            placeholder="Enter Country Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Country Code</label>
          <input
            name="code"
            type="text"
            className="form-control"
            placeholder="Enter Country Code"
            value={formData.code}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className={`btn ${formData.id === null ? 'btn-success' : 'btn-warning'}`}>
          {formData.id === null ? 'Submit' : 'Update'}
        </button>
        {formData.id !== null && (
          <button type="button" className="btn btn-secondary ms-2" onClick={handleCancelEdit}>
            Cancel
          </button>
        )}
      </form>

      <h4 className="mt-5">Country List</h4>

      <div className="table-responsive">
        <table className="table table-bordered table-striped mt-3">
          <thead className="table-dark">
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Code</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {countries.map((c) => (
              <tr key={c.id}>
                <td>{c.id}</td>
                <td>{c.name}</td>
                <td>{c.code}</td>
                <td>
                  <button className="btn btn-sm btn-primary me-2" onClick={() => handleEdit(c)}>Edit</button>
                  <button className="btn btn-sm btn-danger" onClick={() => handleDelete(c.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {countries.length === 0 && (
              <tr>
                <td colSpan="4" className="text-center text-muted">No countries available.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
       <div className="mt-5 text-center">
        <p className="text-muted">
          Developed by <strong>Abhishek Yadav</strong> | Final Year B.Tech Student | AKGEC Ghaziabad
        </p>
      </div>
    </div>
  );
};

export default Country;
