import axios from 'axios';
import { useEffect, useState } from 'react';

const State = () => {
  const [stateList, setStateList] = useState([]);
  const [formData, setFormData] = useState({ id: null, name: '', code: '' });
  const [countries, setCountries] = useState([]);
  const [countryId, setCountryId] = useState('');

  const fetchStates = () => {
    axios.get('http://localhost:5273/api/States')
      .then((res) => setStateList(res.data))
      .catch((err) => console.error('Error fetching states:', err));
  };

  const fetchCountries = () => {
    axios.get('http://localhost:5273/api/Countries')
      .then((res) => setCountries(res.data))
      .catch((err) => console.error('Error fetching countries:', err));
  };

  useEffect(() => {
    fetchStates();
    fetchCountries();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!countryId) {
        alert('Please select a country');
        return;
      }

      if (formData.id === null) {
        await axios.post('http://localhost:5273/api/States', {
          name: formData.name,
          code: formData.code,
          countryId: parseInt(countryId)
        });
        alert('State added successfully!');
      } else {
        await axios.put(`http://localhost:5273/api/States/${formData.id}`, {
          ...formData,
          countryId: parseInt(countryId)
        });
        alert('State updated successfully!');
      }

      setFormData({ id: null, name: '', code: '' });
      setCountryId('');
      fetchStates();
    } catch (error) {
      console.error('Error saving state:', error);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this state?')) return;

    try {
      await axios.delete(`http://localhost:5273/api/States/${id}`);
      alert('State deleted successfully!');
      fetchStates();
    } catch (error) {
      console.error('Error deleting state:', error);
    }
  };

  const handleEdit = (stateItem) => {
    setFormData({ id: stateItem.id, name: stateItem.name, code: stateItem.code });
    setCountryId(stateItem.countryId.toString());
  };

  const handleCancelEdit = () => {
    setFormData({ id: null, name: '', code: '' });
    setCountryId('');
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-primary">Manage State</h2>

      <form onSubmit={handleSubmit} className="border p-4 rounded shadow-sm bg-light">
        <div className="mb-3">
          <label className="form-label">Select Country</label>
          <select
            className="form-select"
            value={countryId}
            onChange={(e) => setCountryId(e.target.value)}
            required
          >
            <option value="" disabled>
              -- Select Country --
            </option>
            {countries.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">State Name</label>
          <input
            name="name"
            type="text"
            className="form-control"
            placeholder="Enter State Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">State Code</label>
          <input
            name="code"
            type="text"
            className="form-control"
            placeholder="Enter State Code"
            value={formData.code}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className={`btn ${formData.id === null ? 'btn-success' : 'btn-warning'}`}>
          {formData.id === null ? 'Submit' : 'Update'}
        </button>
        {formData.id !== null && (
          <button type="button" className="btn btn-secondary ms-2" onClick={handleCancelEdit}>
            Cancel
          </button>
        )}
      </form>

      <h4 className="mt-5">State List</h4>

      <div className="table-responsive">
        <table className="table table-bordered table-striped mt-3">
          <thead className="table-dark">
            <tr>
              <th>Id</th>
              <th>Country Name</th>
              <th>State Name</th>
              <th>Code</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {stateList.map((s) => (
              <tr key={s.id}>
                <td>{s.id}</td>
                <td>{countries.find(c => c.id === s.countryId)?.name || 'Unknown'}</td>
                <td>{s.name}</td>
                <td>{s.code}</td>
                <td>
                  <button className="btn btn-sm btn-primary me-2" onClick={() => handleEdit(s)}>Edit</button>
                  <button className="btn btn-sm btn-danger" onClick={() => handleDelete(s.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {stateList.length === 0 && (
              <tr>
                <td colSpan="5" className="text-center text-muted">No states available.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-5 text-center">
        <p className="text-muted">
          Developed by <strong>Abhishek Yadav</strong> | Final Year B.Tech Student | AKGEC Ghaziabad
        </p>
      </div>
    </div>
  );
};

export default State;
