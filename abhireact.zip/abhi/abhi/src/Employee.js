import axios from "axios";
import { useEffect, useState } from "react";

const Employee = () => {
  const [employees, setEmployees] = useState([]);
  const [countries, setCountries] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [states, setStates] = useState([]);

  const [countryMap, setCountryMap] = useState({});
  const [stateMap, setStateMap] = useState({});
  const [districtMap, setDistrictMap] = useState({});

  const [formData, setFormData] = useState({
    name: "",
    position: "",
    salary: "",
    email: "",
    mobile: "",
    countryId: "",
    stateId: "",
    districtId: ""
  });

  const fetchCountries = () => {
    axios
      .get("http://localhost:5273/api/Countries")
      .then((res) => {
        setCountries(res.data);
        const map = Object.fromEntries(res.data.map((c) => [c.id, c.name]));
        setCountryMap(map);
      })
      .catch((err) => console.error("Error fetching countries:", err));
  };

  const fetchStates = () => {
    axios
      .get("http://localhost:5273/api/States")
      .then((res) => {
        setStates(res.data);
        const map = Object.fromEntries(res.data.map((s) => [s.id, s.name]));
        setStateMap(map);
      })
      .catch((err) => console.error("Error fetching states:", err));
  };

  const fetchDistricts = () => {
    axios
      .get("http://localhost:5273/api/Districts")
      .then((res) => {
        setDistricts(res.data);
        const map = Object.fromEntries(res.data.map((d) => [d.id, d.name]));
        setDistrictMap(map);
      })
      .catch((err) => console.error("Error fetching district:", err));
  };

  const fetchEmployees = () => {
    axios
      .get("http://localhost:5273/api/Employees")
      .then((res) => setEmployees(res.data))
      .catch((err) => console.error("Error fetching employees:", err));
  };

  useEffect(() => {
    fetchCountries();
    fetchStates();
    fetchDistricts();
    fetchEmployees();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:5273/api/Employees", formData)
      .then((res) => {
        alert("Employee added successfully!");
        setFormData({
          name: "",
          position: "",
          salary: "",
          email: "",
          mobile: "",
          countryId: "",
          stateId: "",
          districtId: ""
        });
        fetchEmployees();
      })
      .catch((err) => {
        console.error("Error adding employee:", err);
        alert("Failed to add employee.");
      });
  };

  const handleEdit = (employee) => {
  setFormData({
    id: employee.id,
    name: employee.name,
    position: employee.position,
    salary: employee.salary,
    email: employee.email,
    mobile: employee.mobile,
    countryId: employee.countryId.toString(),
    stateId: employee.stateId.toString(),
    districtId: employee.districtId.toString()
  });
};

const handleDelete = (id) => {
  if (window.confirm("Are you sure you want to delete this employee?")) {
    axios
      .delete(`http://localhost:5273/api/Employees/${id}`)
      .then(() => {
        alert("Employee deleted successfully");
        fetchEmployees(); // Refresh the list
      })
      .catch((err) => {
        console.error("Error deleting employee:", err);
        alert("Failed to delete employee.");
      });
  }
};


  
  return (
    <div className="container">
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-4">
            <label className="form-label">Name</label>
            <input type="text" name="name" value={formData.name} onChange={handleChange} className="form-control" placeholder="Enter name" />
          </div>

          <div className="col-md-4">
            <label className="form-label">Position</label>
            <input type="text" name="position" value={formData.position} onChange={handleChange} className="form-control" placeholder="Enter position" />
          </div>

          <div className="col-md-4">
            <label className="form-label">Salary</label>
            <input type="number" step="0.01" name="salary" value={formData.salary} onChange={handleChange} className="form-control" placeholder="Enter salary" />
          </div>
        </div>

        <div className="row mt-2">
          <div className="col-md-6">
            <label className="form-label">Email</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-control" placeholder="Enter email" />
          </div>

          <div className="col-md-6">
            <label className="form-label">Mobile</label>
            <input type="text" name="mobile" value={formData.mobile} onChange={handleChange} className="form-control" placeholder="Enter mobile number" />
          </div>
        </div>

        <div className="row mt-2">
          <div className="col-md-4">
            <label className="form-label">Country</label>
            <select name="countryId" value={formData.countryId} onChange={handleChange} className="form-select">
              <option value="">Select Country</option>
              {countries.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="col-md-4">
            <label className="form-label">State</label>
            <select name="stateId" value={formData.stateId} onChange={handleChange} className="form-select">
              <option value="">Select State</option>
              {states.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="col-md-4">
            <label className="form-label">District</label>
            <select name="districtId" value={formData.districtId} onChange={handleChange} className="form-select">
              <option value="">Select District</option>
              {districts.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <br />
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>

      <br />
      <table className="table table-bordered table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Position</th>
            <th>Salary</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Country</th>
            <th>State</th>
            <th>District</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="employeeTableBody">
          {employees.map((e) => (
            <tr key={e.id}>
              <td>{e.id}</td>
              <td>{e.name}</td>
              <td>{e.position}</td>
              <td>{e.salary}</td>
              <td>{e.email}</td>
              <td>{e.mobile}</td>
              <td>{countryMap[e.countryId] || "Unknown"}</td>
              <td>{stateMap[e.stateId] || "Unknown"}</td>
              <td>{districtMap[e.districtId] || "Unknown"}</td>
              <td>
              <button className="btn btn-sm btn-primary me-2" onClick={() => handleEdit(e)}>
                Edit
              </button>
              <button className="btn btn-sm btn-danger" onClick={() => handleDelete(e.id)}>
                Delete
              </button>
            </td>
            </tr>
          ))}





        </tbody>
      </table>
    </div>
  );
};

export default Employee;
