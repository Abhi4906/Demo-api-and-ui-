import {BrowserRouter,Link, Route, Routes} from "react-router-dom";
import Home from "./Home";
import About from "./About";
import Country from "./Country";
import State from "./State";
import District from "./District";
import Employee from "./Employee";


function App() {
  return (
<><BrowserRouter>
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-3">
      <Link className="navbar-brand" to="/home">Abhi Project</Link>

      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/home">Home</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/about">About</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/country">Country</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/state">State</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/district">District</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/employee">Employee</Link>
          </li>
        </ul>
      </div>
    </nav>
       <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/country" element={<Country />} />
          <Route path="/state" element={<State />} />
          <Route path="/district" element={<District />} />
          <Route path="/employee" element={<Employee/>} />
        </Routes>
    </BrowserRouter></>
  );
}

export default App;
