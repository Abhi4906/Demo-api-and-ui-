import React from 'react';
import demoImage from './abhi.jpg';

const Home = () => {
  return (
    <div className="container mt-5">
      <div className="text-center mb-4">
        <h1 className="text-primary">Welcome to the Abhi Project Website</h1>
        <p className="lead">
          This website is <strong>created for practice purposes only</strong>. It is part of a learning project to build skills in React, .NET Core, APIs, and more.
        </p>
      </div>

      <div className="d-flex justify-content-center">
        <img
          src={demoImage}
          alt="Demo"
          className="img-fluid rounded shadow"
          style={{ maxHeight: '400px' }}
        />
      </div>

      <div className="mt-5 text-center">
        <p className="text-muted">
          Developed by <strong>Abhishek Yadav</strong> | Final Year B.Tech Student | AKGEC Ghaziabad
        </p>
      </div>
    </div>
  );
};

export default Home;
