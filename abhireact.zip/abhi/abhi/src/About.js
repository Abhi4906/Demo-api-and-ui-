import React from 'react';

const About = () => {
  return (
    <div className="container mt-5">
      <div className="card shadow p-4 bg-light">
        <h2 className="text-primary mb-3">About Me</h2>

        <p className="fs-5">
          My name is <strong>Abhishek Yadav</strong>. I am currently a <strong>4th year B.Tech student</strong> at <strong>Ajay Kumar Garg Engineering College (AKGEC), Ghaziabad</strong>.
        </p>

        <p className="fs-5">
          I belong to <strong>Ballia district</strong> in Uttar Pradesh. I am passionate about technology and continuously strive to improve my skills to become a better developer.
        </p>

        <p className="fs-5">
          I have <strong>5 months of hands-on experience</strong> in software development. During this time, I have worked with the following technologies:
        </p>

        <ul className="fs-5">
          <li>React.js</li>
          <li>.NET Core</li>
          <li>REST APIs</li>
          <li>AWS</li>
          <li>Node.js</li>
        </ul>

        <p className="fs-5">
          I am actively seeking opportunities to build a career in the software industry. I enjoy learning new technologies and solving real-world problems through code.
        </p>

        <p className="text-muted fst-italic">
          "Learning never stops — I strive to improve every day and become more capable."
        </p>
      </div>
       <div className="mt-5 text-center">
        <p className="text-muted">
          Developed by <strong>Abhishek Yadav</strong> | Final Year B.Tech Student | AKGEC Ghaziabad
        </p>
      </div>
    </div>
  );
};

export default About;
