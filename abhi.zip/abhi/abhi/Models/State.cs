﻿namespace abhi.Models
{
    public class State
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string code { get; set; }
        public int CountryId { get; set; } 

    }
}
